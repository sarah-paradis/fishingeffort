import setuptools

setuptools.setup(
    name='fishingeffort',
    version='0.0.1',
    packages=setuptools.find_packages(),
    url='',
    license='',
    author='sarah-paradis',
    author_email='sarah.paradisvilar@gmail.com',
    description='This package provides functions and tools to calculate fishing effort from VMS and AIS data'
)